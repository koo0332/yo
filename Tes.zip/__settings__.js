window.ASSET_PREFIX = "";
window.SCRIPT_PREFIX = "";
window.SCENE_PATH = "1939449.json";
window.CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "high-performance"
};
window.SCRIPTS = [ 165612787, 165612788, 165652235, 165720480, 165721067 ];
window.CONFIG_FILENAME = "config.json";
window.INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
window.PRELOAD_MODULES = [
    {'moduleName' : 'Ammo', 'glueUrl' : 'files/assets/165652322/1/ammo.wasm.js', 'wasmUrl' : 'files/assets/165652323/1/ammo.wasm.wasm', 'fallbackUrl' : 'files/assets/165652321/1/ammo.js', 'preload' : true},
];
